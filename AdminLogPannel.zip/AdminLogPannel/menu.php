<div id="templatemo_menu">
        <ul>
            <li><a href="index.php" class="current">Insert</a></li>
            <li><a href="update.php">Update Records</a></li>
            <li><a href="delete.php">Delete Records</a></li>
        </ul>
        <div class="cleaner"></div>
</div> <!-- end of templatemo_menu -->