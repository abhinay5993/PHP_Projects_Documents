<?php include("account_header.php"); ?>
<?php include("header.php"); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
<style type="text/css">
body{
background-color:#edeff0;
margin:0;
padding:0;
}
#reg{
margin:0 auto;
width:400px;
height:auto;
padding:6px;
background-color:#edeff0;
color:#193847;
font-family:Geneva, Arial, Helvetica, sans-serif;
font-weight:bold;
border:4px solid #FFFFFF;
border-radius:10px;
box-shadow:2px 2px 5px BLUE;
}
h2{
color:#193847;
}
h2:hover{
color:#193847;
}
.txt{
width:200px;
height:20px;
padding:2px;
background-color:#edeff0;
border:2px solid #999999;
color:#193847;
border-radius:4px;
}
.bt{
width:160px;
height:30px;
background-color:#edeff0;
color:#193847;
border:2px solid #003300;
text-align:center;
border-radius:4px;
}
</style>
</head>
<body>
<br />

<div id="reg">
    <?php include("menu.php"); ?>
	 <div align="center"><h2>New Institution Inclusion</h2></div>
	<form name="frm" action="" method="post" enctype="multipart/form-data">
	<table cellpadding="6" cellspacing="6" border="0">
	<tr>
		<td>Name: </td>
		<td><input type="text" name="colgName" class="txt" /></td>
	</tr>
	<tr>
		<td>WebSite URL:</td>
		<td><input type="url" name="colgLink" class="txt" /></td>
	</tr>
	<tr>
		<td>Browse Logo:</td>
		<td><input type="file" name="img" /></td>
	</tr>
	<tr>
	<td></td>
	<div align="center"><td><input type="submit" name="ok" value="Upload Data" class="bt" /></td></div>
	</tr>
	</table>
	</form>
</body>
</html>
